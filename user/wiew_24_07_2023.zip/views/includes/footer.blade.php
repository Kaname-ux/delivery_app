<!-- app footer -->
        <div class="appFooter">
            <div class="footer-title" id="copyright">
                &copy;
            <script>
              document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
            </script>, Jibiat
            </div>
            Systeme de gestion pour vendeur en ligne.
        </div>
        <!-- * app footer -->